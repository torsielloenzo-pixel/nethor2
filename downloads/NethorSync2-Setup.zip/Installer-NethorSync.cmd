@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer-Sync.ps1"
if errorlevel 1 echo Installation interrompue. Verifiez le message ci-dessus.
pause
